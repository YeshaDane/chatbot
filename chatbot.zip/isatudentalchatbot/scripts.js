let pyodide;

async function loadPyodideAndPackages() {
    pyodide = await loadPyodide();
    await pyodide.loadPackage(['nltk']);
    await pyodide.runPythonAsync(`
import sys
sys.path.append('/backend')
from chatbot import main
`);
}

loadPyodideAndPackages();

// DOM elements
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const toggleThemeBtn = document.getElementById('toggleTheme');
const toggleInfoBtn = document.getElementById('toggleInfoBtn');
const infoPanel = document.getElementById('infoPanel');
const appointmentModal = document.getElementById('appointmentModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const calendarContainer = document.getElementById('calendarContainer');
const calendar = document.getElementById('calendar');
const timeSlotContainer = document.getElementById('timeSlotContainer');
const timeSlots = document.getElementById('timeSlots');
const appointmentForm = document.getElementById('appointmentForm');
const reasonSelect = document.getElementById('reason');
const otherReasonContainer = document.getElementById('otherReasonContainer');
const confirmAppointmentBtn = document.getElementById('confirmAppointmentBtn');

// State variables
let selectedDate = null;
let selectedTime = null;
let bookingFlow = false;

// Simulated database of available appointment slots
const availableSlots = {};

// Generate available slots for the next 14 days
const generateAvailableSlots = () => {
    const now = new Date();
    for (let i = 1; i <= 14; i++) {
        const date = new Date(now);
        date.setDate(now.getDate() + i);
        
        // Skip Sundays (clinic closed)
        if (date.getDay() === 0) continue;
        
        const dateStr = date.toISOString().split('T')[0];
        availableSlots[dateStr] = [];
        
        // Monday to Friday: 8:00 AM - 5:00 PM
        if (date.getDay() >= 1 && date.getDay() <= 5) {
            for (let hour = 8; hour < 17; hour++) {
                availableSlots[dateStr].push(`${hour}:00`);
                availableSlots[dateStr].push(`${hour}:30`);
            }
        } 
        // Saturday: 9:00 AM - 2:00 PM
        else if (date.getDay() === 6) {
            for (let hour = 9; hour < 14; hour++) {
                availableSlots[dateStr].push(`${hour}:00`);
                availableSlots[dateStr].push(`${hour}:30`);
            }
        }
        
        // Randomly mark some slots as unavailable (30% chance)
        availableSlots[dateStr] = availableSlots[dateStr].filter(() => Math.random() > 0.3);
    }
};

generateAvailableSlots();

// Render calendar for appointment booking
const renderCalendar = () => {
    // Clear existing days except header
    const headerNodes = Array.from(calendar.children).slice(0, 7);
    calendar.innerHTML = '';
    headerNodes.forEach(node => calendar.appendChild(node));
    
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    // Get the first day of the month
    const firstDay = new Date(currentYear, currentMonth, 1).getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'text-center p-1';
        calendar.appendChild(emptyCell);
    }
    
    // Add days of the month
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    for (let i = 1; i <= daysInMonth; i++) {
        const date = new Date(currentYear, currentMonth, i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayCell = document.createElement('div');
        dayCell.className = 'text-center p-1';
        
        const dayBtn = document.createElement('button');
        dayBtn.textContent = i;
        dayBtn.className = 'w-8 h-8 rounded-full';
        
        // Style based on availability and selection
        if (date < now || date.getDay() === 0 || !availableSlots[dateStr] || availableSlots[dateStr].length === 0) {
            dayBtn.className += ' bg-gray-200 text-gray-400 cursor-not-allowed dark:bg-gray-700 dark:text-gray-500';
            dayBtn.disabled = true;
        } else {
            dayBtn.className += ' hover:bg-primary-100 dark:hover:bg-primary-900 cursor-pointer';
            if (selectedDate === dateStr) {
                dayBtn.className += ' bg-primary-500 text-white';
            }
            
            dayBtn.addEventListener('click', () => {
                selectedDate = dateStr;
                renderCalendar();
                renderTimeSlots(dateStr);
            });
        }
        
        dayCell.appendChild(dayBtn);
        calendar.appendChild(dayCell);
    }
};

// Render time slots for the selected date
const renderTimeSlots = (dateStr) => {
    timeSlots.innerHTML = '';
    timeSlotContainer.classList.remove('hidden');
    
    if (!availableSlots[dateStr] || availableSlots[dateStr].length === 0) {
        const noSlots = document.createElement('div');
        noSlots.className = 'col-span-3 text-center p-2 text-gray-500';
        noSlots.textContent = 'No available slots for this date.';
        timeSlots.appendChild(noSlots);
        return;
    }
    
    availableSlots[dateStr].forEach(timeStr => {
        const slot = document.createElement('button');
        const [hour, minute] = timeStr.split(':');
        const formattedTime = `${hour % 12 || 12}:${minute} ${hour >= 12 ? 'PM' : 'AM'}`;
        
        slot.textContent = formattedTime;
        slot.className = 'p-2 border border-gray-300 dark:border-gray-600 rounded text-center';
        
        if (selectedTime === timeStr && selectedDate === dateStr) {
            slot.className += ' bg-primary-500 text-white';
        } else {
            slot.className += ' hover:bg-primary-100 dark:hover:bg-primary-900';
        }
        
        slot.addEventListener('click', () => {
            selectedTime = timeStr;
            renderTimeSlots(dateStr);
            appointmentForm.classList.remove('hidden');
        });
        
        timeSlots.appendChild(slot);
    });
};

// Function to add a user message to the chat
const addUserMessage = (message) => {
    const messageElement = document.createElement('div');
    messageElement.className = 'flex justify-end';
    messageElement.innerHTML = `
        <div class="bg-primary-500 text-white p-3 rounded-lg max-w-[80%] shadow">
            <p>${message}</p>
        </div>
    `;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
};

// Function to add a bot message to the chat
const addBotMessage = (message, delay = 600) => {
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'flex typing-indicator';
    typingIndicator.innerHTML = `
        <div class="bg-gray-200 dark:bg-gray-700 p-3 rounded-lg max-w-[80%] flex items-center">
            <div class="flex space-x-1">
                <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce"></div>
                <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
            </div>
        </div>
    `;
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    setTimeout(() => {
        typingIndicator.remove();
        const messageElement = document.createElement('div');
        messageElement.className = 'flex';
        messageElement.innerHTML = `
            <div class="bg-gray-200 dark:bg-gray-700 p-3 rounded-lg max-w-[80%]">
                ${message}
            </div>
        `;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, delay);
};

// Event listeners
toggleThemeBtn.addEventListener('click', () => {
    document.documentElement.classList.toggle('dark');
});

toggleInfoBtn.addEventListener('click', () => {
    infoPanel.classList.toggle('hidden');
    infoPanel.classList.toggle('fixed');
    infoPanel.classList.toggle('inset-0');
    infoPanel.classList.toggle('z-40');
    infoPanel.classList.toggle('md:block');
});

closeModalBtn.addEventListener('click', () => {
    appointmentModal.classList.add('hidden');
    bookingFlow = false;
    selectedDate = null;
    selectedTime = null;
    appointmentForm.classList.add('hidden');
    timeSlotContainer.classList.add('hidden');
});

reasonSelect.addEventListener('change', () => {
    if (reasonSelect.value === 'other') {
        otherReasonContainer.classList.remove('hidden');
    } else {
        otherReasonContainer.classList.add('hidden');
    }
});

confirmAppointmentBtn.addEventListener('click', async () => {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const studentId = document.getElementById('studentId').value;
    const reason = reasonSelect.value;
    const otherReason = document.getElementById('otherReason').value;
    
    if (!name || !email || !studentId || !reason) {
        alert('Please fill in all required fields.');
        return;
    }
    
    // Format appointment data
    const appointmentData = {
        name,
        email,
        studentId,
        date: selectedDate,
        time: selectedTime,
        reason: reason === 'other' ? otherReason : reason
    };
    
    // Send to Python backend
    if (pyodide) {
        const response = await pyodide.runPythonAsync(`
main('book appointment', ${JSON.stringify(appointmentData)})
`);
        // Format the date and time for display
        const appointmentDate = new Date(selectedDate);
        const [hour, minute] = selectedTime.split(':');
        const formattedTime = `${hour % 12 || 12}:${minute} ${hour >= 12 ? 'PM' : 'AM'}`;
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = appointmentDate.toLocaleDateString('en-US', dateOptions);
        
        // Remove the selected slot from available slots
        const index = availableSlots[selectedDate].indexOf(selectedTime);
        if (index > -1) {
            availableSlots[selectedDate].splice(index, 1);
        }
        
        // Close the modal and send confirmation message
        appointmentModal.classList.add('hidden');
        addBotMessage(`
            <div class="p-3 bg-green-100 dark:bg-green-900 rounded-lg text-green-800 dark:text-green-100 border border-green-200 dark:border-green-800">
                <p class="font-bold">Appointment Confirmed!</p>
                <p>Name: ${name}</p>
                <p>Date: ${formattedDate}</p>
                <p>Time: ${formattedTime}</p>
                <p>Reason: ${reason === 'other' ? otherReason : reason}</p>
                <p class="mt-2 text-sm">Please arrive 15 minutes before your appointment time.</p>
            </div>
        `);
        bookingFlow = false;
        
        // Reset form and selection state
        selectedDate = null;
        selectedTime = null;
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('studentId').value = '';
        reasonSelect.value = '';
        otherReasonContainer.classList.add('hidden');
        document.getElementById('otherReason').value = '';
    } else {
        addBotMessage("Chatbot is still loading, please wait...");
    }
});

// Handle send button and enter key
const handleSend = async () => {
    const message = userInput.value.trim();
    if (message === '') return;
    
    addUserMessage(message);
    userInput.value = '';
    
    if (bookingFlow) {
        if (message.toLowerCase().includes('cancel') || message.toLowerCase().includes('exit') || message.toLowerCase().includes('stop')) {
            bookingFlow = false;
            addBotMessage("I've canceled the appointment booking process. Is there anything else I can help you with?");
            appointmentModal.classList.add('hidden');
            return;
        } else {
            appointmentModal.classList.remove('hidden');
            renderCalendar();
            addBotMessage("Please select an available date and time for your appointment.");
            return;
        }
    }
    
    if (pyodide) {
        const response = await pyodide.runPythonAsync(`main("${message.replace(/"/g, '\\"')}")`);
        if (response.includes("appointment")) {
            bookingFlow = true;
            appointmentModal.classList.remove('hidden');
            renderCalendar();
            addBotMessage("Please select an available date and time for your appointment.");
        } else {
            addBotMessage(response);
        }
    } else {
        addBotMessage("Chatbot is still loading, please wait...");
    }
};

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSend();
});

// Initial bot message
addBotMessage(`
    <p>Welcome to ISATU University Dental Clinic! I'm your virtual assistant here to help with:</p>
    <ul class="list-disc pl-5 mt-2">
        <li>Scheduling appointments</li>
        <li>Answering questions about our services</li>
        <li>Providing dental health information</li>
        <li>Sharing clinic hours and contact details</li>
    </ul>
    <p class="mt-2">How can I assist you today?</p>
`, 1000);