import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import json
import os

nltk.download('punkt')
nltk.download('stopwords')

# Simulated JSON database for appointments
APPOINTMENTS_FILE = 'appointments.json'
if not os.path.exists(APPOINTMENTS_FILE):
    with open(APPOINTMENTS_FILE, 'w') as f:
        json.dump([], f)

def load_appointments():
    try:
        with open(APPOINTMENTS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_appointments(appointments):
    with open(APPOINTMENTS_FILE, 'w') as f:
        json.dump(appointments, f)

# FAQ responses
faq_responses = {
    "toothache": "For a toothache, rinse with warm salt water and take an over-the-counter pain reliever like ibuprofen. Please book an appointment for a checkup.",
    "brushing": "Brush your teeth twice daily for two minutes using fluoride toothpaste. Use a soft-bristled brush and replace it every 3-4 months.",
    "flossing": "Floss daily to remove plaque between teeth. Use about 18 inches of floss, winding it around your fingers, and gently slide it between teeth.",
    "services": """
        <p>We offer the following dental services at ISATU University Dental Clinic:</p>
        <ul class="list-disc pl-5 mt-2">
            <li>Dental Checkups and Examinations</li>
            <li>Teeth Cleaning and Polishing</li>
            <li>Cavity Fillings</li>
            <li>Tooth Extractions</li>
            <li>Root Canal Therapy</li>
            <li>Dental X-rays</li>
            <li>Emergency Dental Care</li>
        </ul>
        <p class="mt-2">Is there a specific service you're interested in?</p>
    """,
    "hours": """
        <p>Our clinic hours are:</p>
        <ul class="list-disc pl-5 mt-2">
            <li>Monday - Friday: 8:00 AM - 5:00 PM</li>
            <li>Saturday: 9:00 AM - 2:00 PM</li>
            <li>Sunday: Closed</li>
        </ul>
    """,
    "location": "Our clinic is located at the Health Center in ISATU Main Campus. It's on the ground floor of the Student Services Building.",
    "contact": """
        <p>You can contact us through:</p>
        <ul class="list-disc pl-5 mt-2">
            <li>Phone: (123) 456-7890</li>
            <li>Email: dental@isatu.edu</li>
        </ul>
    """,
    "cost": "Dental services at ISATU University Dental Clinic are provided at subsidized rates for students. Basic services like check-ups and cleanings are free with your student ID. For specialized treatments, please consult with our staff for the current fee structure."
}

# Preprocess user input
def preprocess(text):
    tokens = word_tokenize(text.lower())
    stop_words = set(stopwords.words('english'))
    tokens = [t for t in tokens if t not in stop_words]
    return tokens

# Handle appointment booking
def handle_appointment_booking(appointment_data):
    appointments = load_appointments()
    appointments.append(appointment_data)
    save_appointments(appointments)
    return f"Appointment booked for {appointment_data['name']} on {appointment_data['date']} at {appointment_data['time']}."

# Process user input
def process_input(user_input, appointment_data=None):
    if appointment_data:
        return handle_appointment_booking(appointment_data)
    
    tokens = preprocess(user_input)
    
    # Check for appointment booking
    if "book" in tokens or "appointment" in tokens or "schedule" in tokens or "reserve" in tokens:
        return "Please select an available date and time for your appointment."
    
    # Check for FAQ topics
    for token in tokens:
        for key, response in faq_responses.items():
            if key in token:
                return response
    
    # Check for greetings
    if any(token in ["hi", "hello", "hey", "greetings"] for token in tokens):
        return "Hello! Welcome to ISATU University Dental Clinic. How can I help you today?"
    
    # Check for thank you
    if any(token in ["thank", "thanks", "appreciate"] for token in tokens):
        return "You're welcome! Is there anything else I can help you with?"
    
    # Check for goodbye
    if any(token in ["bye", "goodbye", "see", "farewell"] for token in tokens):
        return "Thank you for chatting with ISATU University Dental Clinic's virtual assistant. Have a great day, and remember to keep smiling!"
    
    return "I'm not sure I understand. You can ask me about our services, clinic hours, booking an appointment, or dental health tips. How can I help you today?"

# Main function
def main(user_input, appointment_data=None):
    return process_input(user_input, appointment_data)